#!/usr/bin/env bash
# ============================================================
# Hiwar (حوار) — مشغّل الحزمة الكاملة
# يبقي الخادم (مع الحارس الذاتي) والنفق العام حيّين معاً،
# ويعيد تشغيل أي منهما تلقائياً إذا توقف لأي سبب.
#
# الاستخدام:  ./run.sh
# ============================================================
set -u
DIR="$(cd "$(dirname "$0")" && pwd)"
HIWAR="$DIR/hiwar"
CF="${CLOUDFLARED:-$DIR/cloudflared}"

echo "▶ تشغيل حارس الخادم (إصلاح ذاتي دائم)…"
( while true; do
    cd "$HIWAR" && node guard.js
    echo "↻ الحارس توقف — إعادة تشغيله خلال ثانيتين…"
    sleep 2
  done ) &

if [ -x "$CF" ]; then
  echo "▶ تشغيل النفق العام (رابط https)…"
  ( while true; do
      "$CF" tunnel --url http://localhost:3000 --no-autoupdate
      echo "↻ النفق توقف — إعادة تشغيله خلال 3 ثوانٍ…"
      sleep 3
    done ) &
fi

echo "✅ كل شيء يعمل. أبقِ هذه النافذة مفتوحة."
wait
